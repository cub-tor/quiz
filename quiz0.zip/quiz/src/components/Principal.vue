<template>

 <!-- <div v-if="categoriaActual">
    <h1>{{ categoriaActual.nombre_categoria }}</h1>
  </div>
  <div v-if="preguntaAleatoria">
    <p>{{ preguntaAleatoria.enunciado_pregunta }} </p>
  </div>
  <div v-if="respuestas">
    <div v-for="(respuesta, index) in respuestas" :key="index" class="res">
      <input type="radio" :id="index" :name="'respuesta'" :value="respuesta.id_respuesta" v-model="respuestaSeleccionada" />
      <label :for="index">{{ respuesta.enunciado_respuesta }}</label><br />
    </div>
  </div>
  <div>
    <button id="respuesta" @click="processAnswer">Responder</button>
  </div>
  <div>
  <button v-if="mostrarBotonVolverAjugar" @click="reset">Volver a jugar</button>
</div>-->
<div v-if="categoriaActual">
    <h1>{{ categoriaActual.nombre_categoria }}</h1>
  </div>
  <div v-if="preguntas">
    <p>{{ preguntas.enunciado_pregunta }} </p>
  </div>
  <div v-if="respuestas">
    <div v-for="(respuesta, index) in respuestas" :key="index" class="res">
      <input type="radio" :id="index" :name="'respuesta'" :value="respuesta.id_respuesta" v-model="respuestaSeleccionada" />
      <label :for="index">{{ respuesta.enunciado_respuesta }}</label><br />
    </div>
  </div>
  <div>
    <button id="respuesta" @click="processAnswer">Responder</button>
  </div>
  <div>
  <button v-if="mostrarBotonVolverAjugar" @click="reset">Volver a jugar</button>
  <button v-if="mostrarBotonVerPuntuacion" @click="obtenerPuntuacionTotal">Ver Puntuación</button>
</div>
<div v-if="mostrarBotonVerPuntuacion">
  <p>Puntuación total: {{ puntuacionTotal }}</p>
</div>

      
    
</template>

  
  
<script>
import axios from 'axios';
import { ref, onMounted } from 'vue';
import { auth } from '@/firebaseConfig.js';
import { reactive } from 'vue';


export default {
  setup() {
    const categorias = ref([]);
    const preguntas = ref([]);
    const respuestas = ref([]);
    const categoriaActual = ref(null);
    let category = 0;
    let id_pregunta;
    const preguntaIndex = ref(0);
    const preguntaAleatoria =ref(null);
    const respuestaSeleccionada = ref(null);
    let valorCategoriaActual;
    let id_respuesta;
    const puntos = ref(0);
    const mostrarBotonVolverAjugar = ref(false);
    const mostrarBotonVerPuntuacion = ref(false);
    const data = ref({ puntuacionTotal: 0 });
    var localMode=true;

    function URLServer() {
      if (localMode) {
        return 'http://localhost:3000';
      }
      else {
        return 'https://elsapi.com';
      }
    }

    //Obtener los datos del usuario que ha iniciado sesión
    const obtenerDatosUsuarioActual = () => {
      const usuarioActual = auth.currentUser;
      if (usuarioActual) {//verifica si hay un usuario actual
          const { email } = usuarioActual;
          return { email };//objeto comun  de firebase
      } else {
          return null;
      }
    }


    //Obtiene la categoría correspondiente. 
    const cargarQuiz= async ()=> {
      try {

        const datosJugador = obtenerDatosUsuarioActual();
        const email = datosJugador.email;
        console.log("Datos jugador antes de cargar partida es: ", email)
        //Crear u obtener una partida una partida
        await obtenerPartida(email);
        
        //Llama a obtenerSiguienteCategoria para establecer una categoría
        //valorCategoriaActual.value = await obtenerSiguienteCategoria();
        valorCategoriaActual = await obtenerSiguienteCategoria();
        console.log('valorCategoriaActual',valorCategoriaActual); 
        
        await getPreguntaAleatoriaConRespuestas(valorCategoriaActual);
        //await getPreguntaAleatoriaConRespuestas(valorCategoriaActual.value.nombre_categoria);

        //Llama a obtenerPreguntasPorCategoria, que obtiene las preguntas de esa categoría
        //const preguntasPorCategoria = await obtenerPreguntasPorCategoria(valorCategoriaActual);
        //console.log("En preguntasPorCategorias:", preguntasPorCategoria.length);

        //Llama a random para escoger una pregunta al azar
        //id_pregunta = randomQuestion(preguntasPorCategoria.length);
        //randomQuestion(preguntasPorCategoria.length);
       //id_pregunta = preguntasPorCategoria[randomQuestion(preguntasPorCategoria.length)].id_pregunta;
       // console.log("preguntaIndex despues de llamar a randomQ vale ", preguntaIndex.value);
        
        //preguntaAleatoria.value = preguntasPorCategoria.find(pregunta => pregunta.id_pregunta === id_pregunta);
        //preguntaAleatoria.value = preguntasPorCategoria[preguntaIndex.value];
        //console.log("preguntaAleatoria vale ", preguntaAleatoria.value);  
        //console.log("el id de preguntaAleatoria vale ", preguntaAleatoria.value.id_pregunta);  
        
        //Llama a obtenerRespuestasPorPregunta para poder seleccionar una respuesta de esa pregunta
        //await obtenerRespuestasPorPregunta(preguntaIndex.value+1);
        //await obtenerRespuestasPorPregunta(id_pregunta);
        //console.log ("id_pregunta al obtener respuestas vale: ", preguntaIndex.value+1);
        //console.log ("En obtenerRespuestasPorPregunta: ", obtenerRespuestasPorPregunta(preguntaIndex.value+1));

        //id_respuesta = respuestas.value.find(respuesta => respuesta.correcta === true).id_respuesta;

      } catch (error) {
        console.error('Error:', error);
      }
    };

    /*const obtenerPartida = async () => {
      try {
        const datosJugador = obtenerDatosUsuarioActual();
        const email = datosJugador.email;
        const response = await axios.get(`${URLServer()}/partida?email=${email}`);
        //const response = await axios.get('http://localhost:3000/categoria');
        const partida = response.data;
        if (partida) {
          console.log("La partida se ha creado");
          
        }

      } catch (error) {
        console.error('Error al obtener la partida', error);
      }
    }*/
    
    const obtenerPartida = async (email) => {
      try {
        const response = await axios.get(`${URLServer()}/partida/${email}`);
        //const response = await axios.get('http://localhost:3000/categoria');
        const partida = response.data;
        if (partida) {
          console.log("La partida se ha creado");
          
        }

      } catch (error) {
        console.error('Error al obtener la partida', error);
      }
    }

    const obtenerSiguienteCategoria = async () => {
      try {
        const response = await axios.get(`${URLServer()}/categoria`);
        //const response = await axios.get('http://localhost:3000/categoria');
        categorias.value = response.data;
        if (categorias.value.length > 0) {
          //categoriaActual es una referencia, hay que asignar el valor a su propiedad value
          categoriaActual.value= categorias.value[chooseCategory()];
          valorCategoriaActual = categoriaActual.value.nombre_categoria;
          console.log(valorCategoriaActual);
          return valorCategoriaActual;
        }

      } catch (error) {
        console.error('Error al obtener las categorias:', error);
      }
    }
    
    //Obtiene las preguntas de una categoría concreta
    /*const obtenerPreguntasPorCategoria = async (nombre_categoria=valorCategoriaActual) => {
      try {
        const response = await axios.get(`http://localhost:3000/preguntas/${nombre_categoria}`);
        preguntas.value = response.data;
        console.log("En obtenerPreguntasPorCategoria:", preguntas.value.length);
        return preguntas.value;
      } catch (error) {
        console.error('Error al obtener las preguntas por categoria:', error);
      }
    };*/

    //Obtener una pregunta aleatoria de una categoria y sus respuestas
    const getPreguntaAleatoriaConRespuestas = async (nombre_categoria=valorCategoriaActual) => {
      try {
        //const response = await axios.get(`http://localhost:3000/${nombre_categoria}`);
        const response = await axios.get(`${URLServer()}/${nombre_categoria}`);
        preguntas.value = response.data.pregunta;
        id_pregunta = preguntas.value.id_pregunta;//añadido
        //console.log("id_pregunta vale: ", id_pregunta);//añadido
        //console.log("En obtenerPreguntaAleatoria:", preguntas.value.length);
        respuestas.value = response.data.respuestas;
        //console.log("En obtener ConRespuestas:", respuestas.value.length);
      } catch (error) {
        //console.error('Error al obtener las preguntas por categoria:', error);
      }
    };

    //Obetener respuestas por pregunta
    /*const obtenerRespuestasPorPregunta = async (id_pregunta) => {
      try{
        const response = await axios.get(`http://localhost:3000/respuestas/${id_pregunta}`);
        respuestas.value = response.data;
        console.log("En obtenerRespuestasPorPregunta: ", respuestas.value.length);
        return respuestas.value;

      }catch (error){
        console.log('Error al obtener las respuestas');
        console.error('Error al obtener las respuestas');
      }
    }*/

      //Elegir categoría 
    function chooseCategory() {
      if (category < 5) {
        category = category+1;
      } else{
        category = 0;
      }
      return category
    }

    //Función random, elegir una pregunta al azar
    /*function randomQuestion(max) {
      preguntaIndex.value = Math.floor(Math.random() * max );
      console.log("preguntaIndex vale ", preguntaIndex.value);
      if( categoriaActual.value === "Física"){
        return preguntaIndex.value;
      } else if (categoriaActual.value === "Química" ){
        preguntaIndex.value += 12;
        return preguntaIndex.value;
      } else if (categoriaActual.value === "Matemáticas" ){
        preguntaIndex.value += 25;
        return preguntaIndex.value;
      } else if (categoriaActual.value === "Biología" ){
        preguntaIndex.value += 37;
        return preguntaIndex.value;
      } else if (categoriaActual.value === "Medicina" ){
        preguntaIndex.value += 50;
        return preguntaIndex.value;
      } else if (categoriaActual.value === "Tecnología" ){
        preguntaIndex.value += 63;
        return preguntaIndex.value;
      }
      
    }*/
    
    //Chequear
    /*const chequearRespuesta = async (id_pregunta) => {
      try{
        
        const inputRespuestas = document.querySelectorAll('input[name="respuesta"]');
        console.log("inputRespuestas es ", inputRespuestas);
        
        for (const respuesta of inputRespuestas) {
          if (respuesta.checked) {
            id_respuesta = respuesta.value;//id_respuesta recogido en el formulario
          
            break;
          }
        }
        console.log("id_respuesta es el id_respuesta de la seleccionada: ",id_respuesta);
        
        //Lo que se envía al back
        //const response = await axios.post(`http://localhost:3000/respuestas/${id_pregunta}/${id_respuesta}`);
        const response = await axios.post(`${URLServer()}/respuestas/${id_pregunta}/${id_respuesta}`);    
        if (response.data.correcta) {
          console.log("Respuesta correcta");
          puntos.value +=1;
          let datosJugador = obtenerDatosUsuarioActual();
          console.log("Los datos del jugador son: ",datosJugador);
          //await axios.post('http://localhost:3000/puntos', { puntos: puntos.value, email: datosJugador.email});
          await axios.post(`${URLServer()}/puntos`, { puntos: puntos.value, email: datosJugador.email});
        } else {
          console.log("Respuesta incorrecta");	
        }
      } catch (error) { 
        console.error(error, "al chequear respuesta");
      }
      
    
    }*/

    const chequearRespuesta = async (id_pregunta) => {
      try {
        const inputRespuestas = document.querySelectorAll('input[name="respuesta"]');
        console.log("inputRespuestas es ", inputRespuestas);

        for (const respuesta of inputRespuestas) {
          if (respuesta.checked) {
            id_respuesta = respuesta.value; // id_respuesta recogido en el formulario

            break;
          }
        }
        console.log("id_respuesta es el id_respuesta de la seleccionada: ", id_respuesta);

        // Obtener el email del jugador (ajusta esto según cómo obtengas el email en el front-end)
        const datosJugador = obtenerDatosUsuarioActual();
        const email = datosJugador.email;

        // Enviar el email junto con los otros datos al back-end
        const response = await axios.post(`${URLServer()}/respuestas/${id_pregunta}/${id_respuesta}`, { email });

        if (response.data.correcta) {
          console.log("Respuesta correcta");
          //enviarPuntosAlServidor(puntos.value, datosJugador.email);//añadido ahora
          //puntos.value += 1;
          console.log("Los datos del jugador son: ", datosJugador);
          //await axios.post(`${URLServer()}/partida/:email`);//, { puntos: puntos.value, email: datosJugador.email });
          return true;
        } else {
          console.log("Respuesta incorrecta");
          return false;
        }
      } catch (error) {
      console.error(error, "al chequear respuesta");
     }
    }


    //Comprobar última categoría
    function lastCategory() {
      if (category==5) {
        return true;
      }
      else {
        return false;
      }
    }


    //Procesar respuesta
    function processAnswer() {

      //comprobar respuesta
      //chequearRespuesta(preguntaIndex.value+1);
      chequearRespuesta(id_pregunta);

      //Quitar la propiedad checked de la pregunta anterior
      let radio= document.querySelector('input[name="respuesta"]:checked');
  		radio.checked = false;
      
      //Comprobar si es última categoría
      if (lastCategory()) {						
          //si es la última categoria pintar botón para recargar pantalla al hacer click
          //console.log("última categoría, vuelve a empezar");
          category= 0;
          //preguntaIndex.value = 0;
          //console.log("category vale: ", category);
          mostrarBotonVolverAjugar.value = true;
          mostrarBotonVerPuntuacion.value = true;
          const datosJugador = obtenerDatosUsuarioActual();
          const email = datosJugador.email;
          let puntuacionPartida = obtenerPuntuacionPartida(email);
          let puntuacionTotal = obtenerPuntuacionTotal();
          console.log("Tienes estos puntos en esta categoria: ", puntuacionPartida);
          console.log("Tienes estos puntos totales: ", puntuacionTotal);
          alert("Tienes estos puntos en esta categoria: ", puntuacionPartida);
          //cargarQuiz();
      } else {
          //si no es la última categoría, cargar pregunta de la siguiente categoria 
          cargarQuiz();	
        }
    
    }

  async function obtenerPuntuacionTotal() {
    try {
      const datosJugador = obtenerDatosUsuarioActual();
      const email = datosJugador.email;
      const response = await axios.get(`${URLServer()}/jugador/${email}`);
      data.value.puntuacionTotal= response.data.puntuacionTotal;
      let puntuacionJugador = data.value.puntuacionTotal.puntos_totales;
      console.log("puntuacion Total vale: ", puntuacionJugador);
      mostrarBotonVerPuntuacion.value = false;
      //return response.data.puntuacionTotal;
      return puntuacionJugador;
    } catch (error) {
      console.error('Error al obtener la puntuación total:', error);
      return null;
    }
  }

  async function obtenerPuntuacionPartida() {
    try {
      const datosJugador = obtenerDatosUsuarioActual();
      const email = datosJugador.email;
      const response = await axios.get(`${URLServer()}/partida/${email}`);
      console.log("puntuacionPartida vale: ", response.data.puntuacionPartida);
      return response.data.puntuacionPartida;
    } catch (error) {
        console.error('Error al obtener la puntuación por partida:', error);
        return null;
    }
  }

  /*async function enviarPuntosAlServidor(puntos, email) {
    try {
      await axios.post(`${URLServer()}/puntos`, { puntos, email });
    } catch (error) {
      console.error('Error al enviar los puntos al servidor:', error);
    }
  }*/

    //Función para volver a jugar
    function reset (){
      puntos.value = 0;
      category= 0;
      //preguntaIndex.value = 0;
      //preguntaAleatoria.value = null;
      mostrarBotonVolverAjugar.value = false;
      cargarQuiz();
    }

  

    //Acciones que deben realizarse cuando el componente se monta por primera vez.
    onMounted(() => {
      cargarQuiz();
      
    });

    //Objeto de retorno  
    return {
      categorias,
      preguntas,
      categoriaActual,
      valorCategoriaActual,
      obtenerSiguienteCategoria,
      //obtenerPreguntasPorCategoria,
      preguntaAleatoria,
      //obtenerRespuestasPorPregunta,
      respuestaSeleccionada,
      respuestas,
      preguntaIndex,
      //randomQuestion,
      id_pregunta,
      chequearRespuesta,
      processAnswer,
      puntos,
      obtenerDatosUsuarioActual,
      mostrarBotonVolverAjugar,
      reset,
      getPreguntaAleatoriaConRespuestas,
      URLServer,
      obtenerPuntuacionTotal,
      obtenerPuntuacionPartida,
      mostrarBotonVerPuntuacion,
      obtenerPartida,
      data
      //enviarPuntosAlServidor
    };
  },
};

</script>
  