<template>
    <form @submit.prevent = "handleSubmit">
        <input type="nombre" placeholder="nombre" v-model = "nombre">
        <input type="email" placeholder="ejemplo@email.com" v-model = "email">
        <input type="password" placeholder="constraseña" v-model = "password">
        <button type= "submit">Crear usuario</button>
    
    </form>
    <button @click="logoutUser">Salir</button>
</template>

<script>

import { getAuth, createUserWithEmailAndPassword, signOut } from "firebase/auth" ;
import { auth } from '../firebaseConfig';
import { ref } from 'vue';
import { useRouter } from 'vue-router'
import axios from "axios";

export default {
  setup() {
    const router = useRouter();
    const nombre = ref("");
    const email = ref("");
    const password = ref("");
    var registerOk = false;

   

    const handleSubmit = async () => {
      if (!email.value || password.value.length < 6) {
        return alert("Los campos son obligatorios y la contraseña debe tener al menos 6 caracteres");
      }
      console.log(email.value);
      console.log(password.value);
      console.log("Procesando formulario");
    
      // Registro de usuario
      await registerUser(email.value, password.value);
      if (registerOk) {
        await enviarDatosAlServidor(nombre.value, email.value, password.value);

        // Al hacer el registro llevar al usuario a la pagina principal
        router.push('/Principal');
      } else {
        alert("Revisa los campos y vuelve a intentarlo");
      }
    };

    const registerUser = async (email, password) => {
      try {
        const { user } = await createUserWithEmailAndPassword(auth, email, password);
        registerOk= true;
        console.log(user);
        this.user = { email: user.email, uid: user.uid }
        console.log("user.email es: ", user.email);
        console.log("user.uid es: ", user.uid);
      } catch (error) {
        const errorCode = error.code;
        const errorMessage = error.message;
        console.log(errorCode);
        console.log(errorMessage);
      }
    };

    const enviarDatosAlServidor = async (nombre, email, password) => {
      try {
        const response = await axios.post("http://localhost:3000/login", {
          nombre: nombre,
          email: email,
          password: password
        });
        console.log("Respuesta del servidor: ", response.data);
      } catch (error) {
        console.error("Error enviando datos al servidor: ", error);
      }
    };

    const logoutUser = async () => {
      try {
        await signOut(auth);
        this.user = null;
        console.log("Al salir user vale: ", this.user);
      } catch (error) {
        console.log("error al hacer logout: ", error);
      }
    }

    return {
      handleSubmit,
      logoutUser,
      nombre,
      email,
      password,
    };
  },
};





</script>