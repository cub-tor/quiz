<script>
//import Pregunta from './components/Pregunta.vue';
//import Principal from './components/Principal.vue';
//import Respuestas from './components/Respuestas.vue';
//import Formulario from './components/Formulario.vue';
import FormularioLogin from './components/FormularioLogin.vue';

export default {
  name: 'App',
  components: {
    //Pregunta,
    //Principal,
    FormularioLogin
    
  }
};

</script>

<template>
  <div>
    
    <!--<principal></principal>
    <formulario></formulario>-->
    <h1> QUIZ CIENTÍFICO</h1>
    <nav>
      <router-link to = "/">Login</router-link><br>
      <router-link to = "/Formulario">Registro</router-link>
      
      
    </nav>
    <router-view></router-view>
    
  </div>
</template>
